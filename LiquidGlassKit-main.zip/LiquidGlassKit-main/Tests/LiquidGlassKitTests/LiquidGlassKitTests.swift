//
//  LiquidGlassBadge.swift
//  LiquidGlassKit
//
//  Created by Mason Blumling on 11/23/25.
//

import XCTest
@testable import LiquidGlassKit

final class Liquid_GlassTests: XCTestCase {
    func testExample() throws {
        // XCTest Documentation
        // https://developer.apple.com/documentation/xctest

        // Defining Test Cases and Test Methods
        // https://developer.apple.com/documentation/xctest/defining_test_cases_and_test_methods
    }
}
